// Booking Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const doctors = [
        { id: 1, name: "Dr. Sarah Johnson", specialty: "Cardiologist" },
        { id: 2, name: "Dr. Michael Chen", specialty: "Neurologist" },
        { id: 3, name: "Dr. Emily Rodriguez", specialty: "Pediatrician" },
        { id: 4, name: "Dr. James Wilson", specialty: "Dermatologist" },
        { id: 5, name: "Dr. Lisa Thompson", specialty: "Orthopedic Surgeon" },
        { id: 6, name: "Dr. Robert Brown", specialty: "Psychiatrist" }
    ];

    const timeSlots = [
        "09:00 AM", "10:00 AM", "11:00 AM", 
        "02:00 PM", "03:00 PM", "04:00 PM"
    ];

    // Populate doctors dropdown
    const doctorSelect = document.getElementById('doctor');
    doctors.forEach(doctor => {
        const option = document.createElement('option');
        option.value = doctor.id;
        option.textContent = `${doctor.name} - ${doctor.specialty}`;
        doctorSelect.appendChild(option);
    });

    // Populate time slots dropdown
    const timeSelect = document.getElementById('time');
    timeSlots.forEach(time => {
        const option = document.createElement('option');
        option.value = time;
        option.textContent = time;
        timeSelect.appendChild(option);
    });

    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date').min = today;

    // Handle form submission
    document.getElementById('bookingForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            doctor: document.getElementById('doctor').value,
            date: document.getElementById('date').value,
            time: document.getElementById('time').value,
            reason: document.getElementById('reason').value
        };

        // Basic validation
        if (!formData.doctor || !formData.date || !formData.time) {
            alert('Please fill in all required fields');
            return;
        }

        // Backend placeholder for appointment saving
        console.log('Appointment data:', formData);
        
        // Save to localStorage (simulating backend)
        const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
        appointments.push({
            id: Date.now(),
            ...formData,
            status: 'confirmed',
            doctorName: doctors.find(d => d.id == formData.doctor)?.name || 'Unknown Doctor'
        });
        localStorage.setItem('appointments', JSON.stringify(appointments));

        alert('Appointment booked successfully!');
        this.reset();
        
        // Redirect to bookings page
        setTimeout(() => {
            window.location.href = 'bookings.html';
        }, 1000);
    });

    // Network Team Configuration
    console.log('Network Team: Form submission endpoint configured');
});