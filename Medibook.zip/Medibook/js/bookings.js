// Bookings Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const appointmentsBody = document.getElementById('appointmentsBody');
    const noAppointments = document.getElementById('noAppointments');
    const appointmentsTable = document.getElementById('appointmentsTable');

    function loadAppointments() {
        const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
        
        if (appointments.length === 0) {
            appointmentsTable.style.display = 'none';
            noAppointments.style.display = 'block';
            return;
        }

        appointmentsTable.style.display = 'table';
        noAppointments.style.display = 'none';
        appointmentsBody.innerHTML = '';

        appointments.forEach(appointment => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${appointment.doctorName}</td>
                <td>${appointment.date}</td>
                <td>${appointment.time}</td>
                <td>${appointment.reason || 'Not specified'}</td>
                <td><span class="status ${appointment.status}">${appointment.status}</span></td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-small edit-btn" data-id="${appointment.id}">Edit</button>
                        <button class="btn btn-small btn-danger cancel-btn" data-id="${appointment.id}">Cancel</button>
                    </div>
                </td>
            `;
            appointmentsBody.appendChild(row);
        });

        // Add event listeners
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const appointmentId = this.getAttribute('data-id');
                editAppointment(appointmentId);
            });
        });

        document.querySelectorAll('.cancel-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const appointmentId = this.getAttribute('data-id');
                cancelAppointment(appointmentId);
            });
        });
    }

    function editAppointment(appointmentId) {
        // Security Team Validation
        console.log('Security Team: Edit appointment validation required');
        
        alert(`Editing appointment ID: ${appointmentId}\n\nThis feature would open an edit form in a real application.`);
        // In a real application, this would open a modal or redirect to edit page
    }

    function cancelAppointment(appointmentId) {
        // Security Team Validation
        console.log('Security Team: Cancel appointment authorization check required');
        
        if (confirm('Are you sure you want to cancel this appointment?')) {
            const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
            const updatedAppointments = appointments.map(apt => 
                apt.id == appointmentId ? { ...apt, status: 'cancelled' } : apt
            );
            localStorage.setItem('appointments', JSON.stringify(updatedAppointments));
            
            alert('Appointment cancelled successfully!');
            loadAppointments();
        }
    }

    // Developer Team Section
    console.log('Developer Team: Appointments page loaded');
    
    // Network Team Configuration
    console.log('Network Team: Appointments data fetch endpoint configured');

    // Initial load
    loadAppointments();
});