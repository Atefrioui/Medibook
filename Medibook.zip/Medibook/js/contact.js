// Contact Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    // Form submission
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            name: document.getElementById('contactName').value,
            email: document.getElementById('contactEmail').value,
            phone: document.getElementById('contactPhone').value,
            subject: document.getElementById('contactSubject').value,
            message: document.getElementById('message').value,
            newsletter: document.getElementById('newsletter').checked,
            timestamp: new Date().toISOString()
        };

        // Basic validation
        if (!formData.name || !formData.email || !formData.subject || !formData.message) {
            alert('Please fill in all required fields');
            return;
        }

        // Security Team: Input sanitization
        console.log('Security Team: Input sanitization required for contact form');
        
        // Network Team: Message transmission
        console.log('Network Team: Secure message transmission to support team');

        // Save contact message to localStorage (simulating backend)
        const contactMessages = JSON.parse(localStorage.getItem('contactMessages') || '[]');
        contactMessages.push({
            id: Date.now(),
            ...formData,
            status: 'new'
        });
        localStorage.setItem('contactMessages', JSON.stringify(contactMessages));

        // Developer Team: Contact form processing
        console.log('Developer Team: Contact form submission processed');

        // Show success message
        alert(`Thank you for your message, ${formData.name}! We'll get back to you within 24 hours.`);
        
        // Reset form
        contactForm.reset();
        
        // If newsletter subscribed
        if (formData.newsletter) {
            const subscribers = JSON.parse(localStorage.getItem('newsletterSubscribers') || '[]');
            if (!subscribers.find(sub => sub.email === formData.email)) {
                subscribers.push({
                    email: formData.email,
                    name: formData.name,
                    subscribedAt: new Date().toISOString()
                });
                localStorage.setItem('newsletterSubscribers', JSON.stringify(subscribers));
                console.log('Newsletter subscription added for:', formData.email);
            }
        }
    });

    // Auto-fill form for demo purposes
    function setupDemoData() {
        const userData = JSON.parse(localStorage.getItem('userData') || '{}');
        if (userData.fullName && userData.email) {
            document.getElementById('contactName').value = userData.fullName;
            document.getElementById('contactEmail').value = userData.email;
            document.getElementById('contactPhone').value = userData.phone || '';
        }
    }

    // Add character counter for message
    const messageTextarea = document.getElementById('message');
    const messageCounter = document.createElement('div');
    messageCounter.className = 'message-counter';
    messageCounter.style.fontSize = '12px';
    messageCounter.style.color = 'var(--text-light)';
    messageCounter.style.textAlign = 'right';
    messageCounter.style.marginTop = '5px';
    messageTextarea.parentNode.appendChild(messageCounter);

    messageTextarea.addEventListener('input', function() {
        const length = this.value.length;
        messageCounter.textContent = `${length}/1000 characters`;
        
        if (length > 1000) {
            messageCounter.style.color = 'var(--danger)';
        } else if (length > 800) {
            messageCounter.style.color = 'var(--warning)';
        } else {
            messageCounter.style.color = 'var(--text-light)';
        }
    });

    // Initialize demo data
    setupDemoData();

    // Network Team Configuration
    console.log('Network Team: Contact form endpoint configured with SSL');
    
    // Security Team Configuration
    console.log('Security Team: Contact form CSRF protection implemented');
});