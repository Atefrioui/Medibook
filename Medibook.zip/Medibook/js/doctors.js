// Doctors Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const doctors = [
        {
            id: 1,
            name: "Dr. Sarah Johnson",
            specialty: "Cardiologist",
            location: "City Medical Center",
            experience: "10+ years of experience in cardiology and heart surgery",
            image: "fas fa-user-md"
        },
        {
            id: 2,
            name: "Dr. Michael Chen",
            specialty: "Neurologist",
            location: "Neuro Care Hospital",
            experience: "Specialized in neurological disorders and treatment",
            image: "fas fa-user-md"
        },
        {
            id: 3,
            name: "Dr. Emily Rodriguez",
            specialty: "Pediatrician",
            location: "Children's Health Center",
            experience: "Expert in child healthcare and development",
            image: "fas fa-user-md"
        },
        {
            id: 4,
            name: "Dr. James Wilson",
            specialty: "Dermatologist",
            location: "Skin Care Clinic",
            experience: "Specialized in skin diseases and cosmetic procedures",
            image: "fas fa-user-md"
        },
        {
            id: 5,
            name: "Dr. Lisa Thompson",
            specialty: "Orthopedic Surgeon",
            location: "Bone & Joint Center",
            experience: "Expert in joint replacement and sports injuries",
            image: "fas fa-user-md"
        },
        {
            id: 6,
            name: "Dr. Robert Brown",
            specialty: "Psychiatrist",
            location: "Mental Wellness Center",
            experience: "Specialized in mental health and therapy",
            image: "fas fa-user-md"
        }
    ];

    const doctorsContainer = document.getElementById('doctorsContainer');
    
    doctors.forEach(doctor => {
        const doctorCard = document.createElement('div');
        doctorCard.className = 'doctor-card';
        doctorCard.innerHTML = `
            <div class="doctor-image">
                <i class="${doctor.image}" style="font-size: 60px; color: #ccc;"></i>
            </div>
            <div class="doctor-info">
                <h3>${doctor.name}</h3>
                <p class="doctor-specialty">${doctor.specialty}</p>
                <div class="doctor-location">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${doctor.location}</span>
                </div>
                <p class="doctor-experience">${doctor.experience}</p>
                <div class="doctor-actions">
                    <a href="booking.html?doctor=${doctor.id}" class="btn btn-small">Book Appointment</a>
                    <button class="btn btn-small btn-secondary view-profile" data-id="${doctor.id}">View Profile</button>
                </div>
            </div>
        `;
        doctorsContainer.appendChild(doctorCard);
    });

    // Add event listeners for view profile buttons
    document.querySelectorAll('.view-profile').forEach(button => {
        button.addEventListener('click', function() {
            const doctorId = this.getAttribute('data-id');
            alert(`Viewing profile for doctor ID: ${doctorId}`);
            // In a real application, this would redirect to a doctor profile page
        });
    });
});