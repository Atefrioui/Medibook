// Login Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
    // Check if user is already logged in
    function checkAuthStatus() {
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        const userData = JSON.parse(localStorage.getItem('userData') || '{}');
        
        if (isLoggedIn === 'true' && userData.email) {
            // Auto-fill email if remembered
            document.getElementById('loginEmail').value = userData.email;
            document.getElementById('rememberMe').checked = true;
        }
    }

    // Form submission
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const rememberMe = document.getElementById('rememberMe').checked;

        // Basic validation
        if (!email || !password) {
            alert('Please fill in all fields');
            return;
        }

        // Security Team: Authentication
        console.log('Security Team: Authentication process started');
        
        // Simulate authentication (in real app, this would be API call)
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        const user = users.find(u => u.email === email && u.password === password);
        
        if (user || (email === 'demo@medibook.com' && password === 'password')) {
            // Successful login
            localStorage.setItem('isLoggedIn', 'true');
            
            if (rememberMe) {
                // Store user data for auto-login
                const userData = {
                    email: email,
                    fullName: user ? user.fullName : 'Demo User'
                };
                localStorage.setItem('userData', JSON.stringify(userData));
            }
            
            // Network Team: Session management
            console.log('Network Team: User session established');
            
            alert('Login successful!');
            window.location.href = 'index.html';
        } else {
            alert('Invalid email or password. Please try again.\n\nDemo credentials: demo@medibook.com / password');
        }
    });

    // Social login handlers
    document.querySelector('.google-btn').addEventListener('click', function() {
        alert('Google login would be implemented here');
        // Security Team: OAuth integration required
        console.log('Security Team: Google OAuth integration required');
    });

    document.querySelector('.facebook-btn').addEventListener('click', function() {
        alert('Facebook login would be implemented here');
        // Security Team: OAuth integration required
        console.log('Security Team: Facebook OAuth integration required');
    });

    // Forgot password
    document.querySelector('.forgot-password').addEventListener('click', function(e) {
        e.preventDefault();
        const email = prompt('Please enter your email address to reset your password:');
        if (email) {
            alert(`Password reset instructions have been sent to ${email}`);
            // Security Team: Password reset flow required
            console.log('Security Team: Password reset email system required');
        }
    });

    // Developer Team Section
    console.log('Developer Team: Login page initialized');
    
    // Initial load
    checkAuthStatus();
});