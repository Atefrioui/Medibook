// Main JavaScript for basic functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log('MediBook website loaded successfully');
    
    // Add any global JavaScript functionality here
    
    // Form validation for all forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'var(--danger)';
                } else {
                    field.style.borderColor = 'var(--border)';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    });
    
    // Mobile menu toggle (if needed in future)
    function initMobileMenu() {
        const nav = document.querySelector('nav');
        const authButtons = document.querySelector('.auth-buttons');
        
        if (window.innerWidth <= 768) {
            // Add mobile menu functionality here if needed
        }
    }
    
    // Initialize
    initMobileMenu();
    window.addEventListener('resize', initMobileMenu);
});