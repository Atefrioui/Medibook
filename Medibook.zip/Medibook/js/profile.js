// Profile Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const profileForm = document.getElementById('profileForm');
    const cancelBtn = document.getElementById('cancelBtn');
    
    // Load user data
    function loadUserData() {
        const userData = JSON.parse(localStorage.getItem('userData') || '{}');
        
        if (Object.keys(userData).length === 0) {
            // Default data
            const defaultData = {
                fullName: 'John Doe',
                email: 'john.doe@example.com',
                phone: '+1 (555) 123-4567',
                address: '123 Main Street, City, State 12345',
                dateOfBirth: '1990-01-01',
                memberSince: 'January 2024'
            };
            localStorage.setItem('userData', JSON.stringify(defaultData));
            return defaultData;
        }
        
        return userData;
    }

    function updateProfileDisplay(userData) {
        document.getElementById('fullName').value = userData.fullName;
        document.getElementById('email').value = userData.email;
        document.getElementById('phone').value = userData.phone || '';
        document.getElementById('address').value = userData.address || '';
        document.getElementById('dateOfBirth').value = userData.dateOfBirth || '';
        
        document.getElementById('userName').textContent = userData.fullName;
        document.getElementById('userEmail').textContent = userData.email;
        
        if (userData.memberSince) {
            document.querySelector('.member-since').textContent = `Member since ${userData.memberSince}`;
        }
    }

    function updateStatistics() {
        const appointments = JSON.parse(localStorage.getItem('appointments') || '[]');
        const confirmedAppointments = appointments.filter(apt => apt.status === 'confirmed');
        
        // Count unique doctors
        const uniqueDoctors = new Set(confirmedAppointments.map(apt => apt.doctorName));
        
        document.getElementById('totalAppointments').textContent = confirmedAppointments.length;
        document.getElementById('doctorsVisited').textContent = uniqueDoctors.size;
    }

    // Form submission
    profileForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            fullName: document.getElementById('fullName').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            address: document.getElementById('address').value,
            dateOfBirth: document.getElementById('dateOfBirth').value,
            memberSince: JSON.parse(localStorage.getItem('userData') || '{}').memberSince || 'January 2024'
        };

        // Password change logic
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword || confirmPassword) {
            if (newPassword !== confirmPassword) {
                alert('New passwords do not match!');
                return;
            }
            
            if (newPassword.length < 8) {
                alert('Password must be at least 8 characters long!');
                return;
            }

            // Security Team: Password hashing
            console.log('Security Team: Password hashing required here');
            
            alert('Password changed successfully!');
            
            // Clear password fields
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
        }

        // Save user data
        localStorage.setItem('userData', JSON.stringify(formData));
        
        // Update display
        updateProfileDisplay(formData);
        
        alert('Profile updated successfully!');
        
        // Developer Team Section
        console.log('Developer Team: Profile update completed');
    });

    // Cancel button
    cancelBtn.addEventListener('click', function() {
        const userData = loadUserData();
        updateProfileDisplay(userData);
        
        // Clear password fields
        document.getElementById('currentPassword').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('confirmPassword').value = '';
    });

    // Network Team Configuration
    console.log('Network Team: Profile data synchronization configured');

    // Initial load
    const userData = loadUserData();
    updateProfileDisplay(userData);
    updateStatistics();
});