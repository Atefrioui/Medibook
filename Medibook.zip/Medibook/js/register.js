// Register Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    const passwordInput = document.getElementById('regPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    
    // Create password strength indicator
    function createPasswordStrengthIndicator() {
        const passwordGroup = document.querySelector('.form-group:has(#regPassword)');
        const strengthDiv = document.createElement('div');
        strengthDiv.className = 'password-strength';
        strengthDiv.innerHTML = `
            <div class="strength-bar"></div>
            <div class="strength-text"></div>
        `;
        passwordGroup.appendChild(strengthDiv);
        return strengthDiv;
    }

    const strengthIndicator = createPasswordStrengthIndicator();
    const strengthBar = strengthIndicator.querySelector('.strength-bar');
    const strengthText = strengthIndicator.querySelector('.strength-text');

    // Password strength checker
    function checkPasswordStrength(password) {
        let strength = 0;
        let feedback = [];

        // Length check
        if (password.length >= 8) strength += 1;
        else feedback.push('at least 8 characters');

        // Uppercase check
        if (/[A-Z]/.test(password)) strength += 1;
        else feedback.push('one uppercase letter');

        // Lowercase check
        if (/[a-z]/.test(password)) strength += 1;
        else feedback.push('one lowercase letter');

        // Number check
        if (/[0-9]/.test(password)) strength += 1;
        else feedback.push('one number');

        // Special character check
        if (/[^A-Za-z0-9]/.test(password)) strength += 1;
        else feedback.push('one special character');

        // Update UI
        strengthBar.className = 'strength-bar';
        if (password.length === 0) {
            strengthText.textContent = '';
            return 0;
        }

        if (strength <= 2) {
            strengthBar.classList.add('strength-weak');
            strengthText.textContent = 'Weak password';
            strengthText.style.color = 'var(--danger)';
        } else if (strength <= 4) {
            strengthBar.classList.add('strength-medium');
            strengthText.textContent = 'Medium strength';
            strengthText.style.color = 'var(--warning)';
        } else {
            strengthBar.classList.add('strength-strong');
            strengthText.textContent = 'Strong password';
            strengthText.style.color = 'var(--success)';
        }

        return strength;
    }

    // Real-time password strength feedback
    passwordInput.addEventListener('input', function() {
        checkPasswordStrength(this.value);
    });

    // Real-time password confirmation check
    confirmPasswordInput.addEventListener('input', function() {
        const password = passwordInput.value;
        const confirmPassword = this.value;

        if (confirmPassword && password !== confirmPassword) {
            this.style.borderColor = 'var(--danger)';
        } else {
            this.style.borderColor = 'var(--border)';
        }
    });

    // Form submission
    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            fullName: document.getElementById('regFullName').value,
            email: document.getElementById('regEmail').value,
            phone: document.getElementById('regPhone').value,
            dateOfBirth: document.getElementById('regDateOfBirth').value,
            password: passwordInput.value,
            role: document.getElementById('role').value,
            acceptTerms: document.getElementById('acceptTerms').checked
        };

        // Validation
        if (!formData.acceptTerms) {
            alert('Please accept the Terms of Service and Privacy Policy');
            return;
        }

        // Password validation
        const passwordStrength = checkPasswordStrength(formData.password);
        if (passwordStrength < 3) {
            alert('Please choose a stronger password. Password should include uppercase, lowercase letters and numbers.');
            return;
        }

        if (formData.password !== confirmPasswordInput.value) {
            alert('Passwords do not match!');
            return;
        }

        // Security Team: Password hashing
        console.log('Security Team: Password hashing required before storage');
        
        // Developer Team: User registration
        console.log('Developer Team: User registration process started');

        // Save user to localStorage (simulating database)
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        
        // Check if user already exists
        if (users.find(user => user.email === formData.email)) {
            alert('An account with this email already exists. Please use a different email or login.');
            return;
        }

        // Add new user (in real app, password would be hashed)
        users.push({
            id: Date.now(),
            ...formData,
            createdAt: new Date().toISOString()
        });
        localStorage.setItem('users', JSON.stringify(users));

        // Network Team: Database integration
        console.log('Network Team: User data saved to database');

        // Auto-login after registration
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userData', JSON.stringify({
            fullName: formData.fullName,
            email: formData.email,
            phone: formData.phone,
            role: formData.role,
            memberSince: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
        }));

        alert(`Registration successful! Welcome to MediBook, ${formData.fullName}!`);
        
        // Redirect to home page
        window.location.href = 'index.html';
    });

    // Set maximum date for date of birth (18 years ago)
    const dateOfBirthInput = document.getElementById('regDateOfBirth');
    const maxDate = new Date();
    maxDate.setFullYear(maxDate.getFullYear() - 18);
    dateOfBirthInput.max = maxDate.toISOString().split('T')[0];

    // Terms and Privacy links
    document.querySelectorAll('.terms-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const isTerms = this.textContent.includes('Terms');
            alert(`${isTerms ? 'Terms of Service' : 'Privacy Policy'} would be displayed here`);
        });
    });

    // Developer Team Section
    console.log('Developer Team: Registration page initialized');
});